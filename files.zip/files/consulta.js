"use strict";

/* consulta.js - Listado general y búsqueda individual. */

const botonActualizar = document.getElementById("boton-actualizar");
const contador = document.getElementById("contador");
const mensajeGeneral = document.getElementById("mensaje-general");
const resultadoGeneral = document.getElementById("resultado-general");

const formBusqueda = document.getElementById("form-busqueda");
const campoBusqueda = document.getElementById("busqueda-id");
const botonBuscar = document.getElementById("boton-buscar");
const mensajeBusqueda = document.getElementById("mensaje-busqueda");
const resultadoBusqueda = document.getElementById("resultado-busqueda");


/* ---------- Consulta general ---------- */

function mostrarVacio() {
  const parrafo = document.createElement("p");
  parrafo.className = "vacio";
  parrafo.append("Todavía no hay automóviles cargados. ");
  const enlace = document.createElement("a");
  enlace.href = "alta.html";
  enlace.textContent = "Agregá el primero";
  parrafo.append(enlace, ".");
  resultadoGeneral.replaceChildren(parrafo);
}

async function cargarTodos() {
  establecerCargando(botonActualizar, true, "Actualizando…");
  mostrarMensaje(
    mensajeGeneral,
    "info",
    "Cargando automóviles… si el servidor estaba inactivo, la primera consulta puede tardar hasta un minuto."
  );

  try {
    const autos = await obtenerAutos();
    autos.sort((a, b) => a.id - b.id);
    limpiarMensaje(mensajeGeneral);

    contador.textContent = autos.length === 1 ? "1 automóvil" : `${autos.length} automóviles`;

    if (autos.length === 0) {
      mostrarVacio();
    } else {
      resultadoGeneral.replaceChildren(crearTablaAutos(autos, "Listado de automóviles"));
    }
  } catch (error) {
    contador.textContent = "";
    resultadoGeneral.replaceChildren();
    mostrarMensaje(mensajeGeneral, "error", error.message);
  } finally {
    establecerCargando(botonActualizar, false);
  }
}


/* ---------- Consulta individual ---------- */

async function buscarPorId(evento) {
  evento.preventDefault();
  resultadoBusqueda.replaceChildren();

  const errorId = validarId(campoBusqueda.value);
  if (errorId) {
    mostrarMensaje(mensajeBusqueda, "error", errorId);
    return;
  }

  establecerCargando(botonBuscar, true, "Buscando…");
  limpiarMensaje(mensajeBusqueda);

  try {
    const auto = await obtenerAuto(campoBusqueda.value.trim());
    resultadoBusqueda.replaceChildren(crearTablaAutos([auto], "Automóvil encontrado"));
  } catch (error) {
    mostrarMensaje(mensajeBusqueda, "error", error.message);
  } finally {
    establecerCargando(botonBuscar, false);
  }
}


botonActualizar.addEventListener("click", cargarTodos);
formBusqueda.addEventListener("submit", buscarPorId);
cargarTodos();
