"use strict";

/* alta.js - Alta de automóviles con ID manual o automático. */

const formAlta = document.getElementById("form-alta");
const campoId = document.getElementById("alta-id");
const campoMarca = document.getElementById("alta-marca");
const campoPrecio = document.getElementById("alta-precio");
const selectorColor = document.getElementById("color-selector");
const textoColor = document.getElementById("color-texto");
const botonAgregar = document.getElementById("boton-agregar");
const areaMensaje = document.getElementById("mensaje");

enlazarColor(selectorColor, textoColor);

async function agregar(evento) {
  evento.preventDefault();

  const datos = {
    id: campoId.value.trim(),
    marca: campoMarca.value.trim(),
    precio: campoPrecio.value,
    color: textoColor.value.trim(),
  };

  const errores = validarAuto(datos);
  if (errores.length > 0) {
    mostrarMensaje(areaMensaje, "error", errores);
    return;
  }

  // El ID solo se envía si el usuario lo completó; si no, la API lo genera.
  const auto = {
    marca: datos.marca,
    precio: Number(datos.precio),
    color: datos.color,
  };
  if (datos.id !== "") auto.id = Number(datos.id);

  establecerCargando(botonAgregar, true, "Agregando…");
  limpiarMensaje(areaMensaje);

  try {
    const creado = await crearAuto(auto);
    const idAsignado = creado?.id ?? auto.id;
    const detalle = idAsignado !== undefined ? ` (ID ${idAsignado})` : "";

    mostrarMensaje(areaMensaje, "exito", `Automóvil agregado correctamente${detalle}.`);
    formAlta.reset();
  } catch (error) {
    mostrarMensaje(areaMensaje, "error", error.message);
  } finally {
    establecerCargando(botonAgregar, false);
  }
}

formAlta.addEventListener("submit", agregar);
