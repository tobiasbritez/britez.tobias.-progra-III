"use strict";

/* ==========================================================
   api.js - Comunicación con la API REST de autos.
   Es el único archivo que conoce las URLs y el formato de
   las respuestas. Las páginas solo usan las funciones de abajo.
   ========================================================== */

const API_URL = "https://api-autos-tgwd.onrender.com";
const RUTA_AUTOS = `${API_URL}/autos`;

/** Error con el código HTTP asociado (0 = sin conexión). */
class ErrorApi extends Error {
  constructor(mensaje, estado) {
    super(mensaje);
    this.name = "ErrorApi";
    this.estado = estado;
  }
}


/* ---------- Utilidades internas ---------- */

/** Busca un texto de error dentro de la respuesta del servidor. */
function extraerTexto(datos) {
  if (typeof datos === "string") {
    const texto = datos.trim();
    // Se descartan páginas HTML de error y textos demasiado largos.
    return texto && texto.length < 200 && !texto.startsWith("<") ? texto : "";
  }
  if (datos && typeof datos === "object") {
    for (const clave of ["mensaje", "message", "error"]) {
      if (typeof datos[clave] === "string" && datos[clave].trim()) {
        return datos[clave].trim();
      }
    }
  }
  return "";
}

/** Traduce un código HTTP de error a un mensaje claro para el usuario. */
function construirMensaje(estado, datos) {
  if (estado === 404) return "No existe un automóvil con ese ID.";
  if (estado === 409) return "Ya existe un automóvil con ese ID.";

  const delServidor = extraerTexto(datos);
  if (delServidor) return delServidor;

  if (estado === 400) return "Los datos enviados no son válidos.";
  if (estado >= 500) return "El servidor tuvo un problema. Intentá de nuevo en unos instantes.";
  return `No se pudo completar la operación (código ${estado}).`;
}

/**
 * Devuelve un automóvil a partir de la respuesta de la API.
 * Acepta un objeto directo, un objeto envuelto ({ auto } o { data })
 * y, si se indica, un arreglo (se toma el primer elemento).
 */
function extraerAuto(datos, aceptarArreglo = false) {
  if (Array.isArray(datos)) {
    return aceptarArreglo && datos.length > 0 ? extraerAuto(datos[0]) : null;
  }
  if (datos && typeof datos === "object") {
    if ("marca" in datos) return datos;
    return extraerAuto(datos.auto ?? datos.data ?? null, aceptarArreglo);
  }
  return null;
}

/** Devuelve la lista de automóviles a partir de la respuesta de la API. */
function extraerLista(datos) {
  if (Array.isArray(datos)) return datos;
  if (datos && typeof datos === "object") {
    for (const clave of ["autos", "data", "resultado"]) {
      if (Array.isArray(datos[clave])) return datos[clave];
    }
  }
  return [];
}

/** Ejecuta una solicitud, interpreta el JSON y traduce los errores. */
async function solicitar(url, opciones = {}) {
  let respuesta;
  try {
    respuesta = await fetch(url, opciones);
  } catch {
    throw new ErrorApi(
      "No se pudo conectar con el servidor. Verificá tu conexión e intentá de nuevo.",
      0
    );
  }

  let datos = null;
  const texto = await respuesta.text();
  if (texto) {
    try {
      datos = JSON.parse(texto);
    } catch {
      datos = texto;
    }
  }

  if (!respuesta.ok) {
    throw new ErrorApi(construirMensaje(respuesta.status, datos), respuesta.status);
  }
  return datos;
}

function opcionesJson(metodo, cuerpo) {
  return {
    method: metodo,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(cuerpo),
  };
}


/* ---------- Operaciones disponibles para las páginas ---------- */

/** GET / : indica si el servidor está respondiendo. */
async function comprobarServidor() {
  try {
    const respuesta = await fetch(`${API_URL}/`);
    return respuesta.ok;
  } catch {
    return false;
  }
}

/** GET /autos : devuelve un arreglo de autos. */
async function obtenerAutos() {
  return extraerLista(await solicitar(RUTA_AUTOS));
}

/** GET /autos/:id : devuelve un auto o lanza ErrorApi 404. */
async function obtenerAuto(id) {
  const datos = await solicitar(`${RUTA_AUTOS}/${encodeURIComponent(id)}`);
  const auto = extraerAuto(datos, true);
  if (!auto) throw new ErrorApi("No existe un automóvil con ese ID.", 404);
  return auto;
}

/** POST /autos : el ID es opcional. Devuelve el auto creado si la API lo informa. */
async function crearAuto(auto) {
  return extraerAuto(await solicitar(RUTA_AUTOS, opcionesJson("POST", auto)));
}

/** PUT /autos/:id : modifica marca, precio y color. */
async function modificarAuto(id, datos) {
  return extraerAuto(
    await solicitar(`${RUTA_AUTOS}/${encodeURIComponent(id)}`, opcionesJson("PUT", datos))
  );
}

/** DELETE /autos/:id : elimina el auto. */
async function eliminarAuto(id) {
  await solicitar(`${RUTA_AUTOS}/${encodeURIComponent(id)}`, { method: "DELETE" });
}
