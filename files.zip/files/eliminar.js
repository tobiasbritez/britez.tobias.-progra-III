"use strict";

/* eliminar.js - Buscar un auto, mostrar sus datos, pedir confirmación y eliminarlo. */

const formBuscar = document.getElementById("form-buscar");
const campoBuscarId = document.getElementById("buscar-id");
const botonBuscar = document.getElementById("boton-buscar");
const areaMensaje = document.getElementById("mensaje");

const panelDetalle = document.getElementById("panel-detalle");
const detalle = document.getElementById("detalle");
const botonEliminar = document.getElementById("boton-eliminar");
const botonCancelar = document.getElementById("boton-cancelar");

let autoActual = null;


function mostrarDetalle(auto) {
  autoActual = auto;
  detalle.replaceChildren(crearTablaAutos([auto], "Automóvil a eliminar"));
  panelDetalle.hidden = false;
}

function ocultarDetalle() {
  autoActual = null;
  detalle.replaceChildren();
  panelDetalle.hidden = true;
}


async function buscar(evento) {
  evento.preventDefault();
  ocultarDetalle();

  const errorId = validarId(campoBuscarId.value);
  if (errorId) {
    mostrarMensaje(areaMensaje, "error", errorId);
    return;
  }

  establecerCargando(botonBuscar, true, "Buscando…");
  limpiarMensaje(areaMensaje);

  try {
    mostrarDetalle(await obtenerAuto(campoBuscarId.value.trim()));
  } catch (error) {
    mostrarMensaje(areaMensaje, "error", error.message);
  } finally {
    establecerCargando(botonBuscar, false);
  }
}

async function eliminar() {
  if (!autoActual) return;

  const confirmado = await confirmar({
    titulo: "Eliminar automóvil",
    texto: `Vas a eliminar el automóvil ${autoActual.marca} con ID ${autoActual.id}. Esta acción no se puede deshacer.`,
    textoConfirmar: "Eliminar",
    peligro: true,
  });
  if (!confirmado) return;

  establecerCargando(botonEliminar, true, "Eliminando…");
  limpiarMensaje(areaMensaje);

  try {
    await eliminarAuto(autoActual.id);
    ocultarDetalle();
    formBuscar.reset();
    mostrarMensaje(areaMensaje, "exito", "Automóvil eliminado correctamente.");
  } catch (error) {
    mostrarMensaje(areaMensaje, "error", error.message);
  } finally {
    establecerCargando(botonEliminar, false);
  }
}


formBuscar.addEventListener("submit", buscar);
botonEliminar.addEventListener("click", eliminar);
botonCancelar.addEventListener("click", () => {
  ocultarDetalle();
  limpiarMensaje(areaMensaje);
});
